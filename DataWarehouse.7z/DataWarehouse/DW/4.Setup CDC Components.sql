Use DATAW
GO

EXEC sys.sp_cdc_enable_table
	@source_schema = N'src',
	@source_name   = N'Customers',
	@role_name     = NULL,
	@supports_net_changes = 1
GO