-- Enable CDC
USE DATAW
GO

EXEC sys.sp_cdc_enable_db
GO

EXEC sys.sp_cdc_enable_table
	@source_schema = N'src',
	@source_name   = N'Customers',
	@role_name     = NULL,
	@supports_net_changes = 1
GO


-- Select all changed customer records since the last extraction
DECLARE @from_Date datetime, @to_Date datetime
SELECT @from_Date = MAX(LastExtractTime), @to_Date = getdate()
FROM stg.ExtractLog
WHERE SourceName = 'Customers'

DECLARE @from_lsn binary(10), @to_lsn binary(10);
SET @from_lsn = sys.fn_cdc_map_time_to_lsn('smallest greater than', @from_Date);
SET @to_lsn = sys.fn_cdc_map_time_to_lsn('largest less than or equal', @to_Date);

IF (@from_lsn IS NULL )OR (@to_lsn IS NULL)
	PRINT 'There has been no logged database activity in the specified time interval'
ELSE
SELECT *
FROM cdc.fn_cdc_get_net_changes_src_Customers(@from_lsn, @to_lsn, 'all');


-- Insert a new customer
INSERT INTO src.Customers
VALUES
(45, 'Ben Miller', 'ben@contoso.com', '90010', 'Los Angeles', 'California', 'United States')
GO
TRUNCATE TABLE stg.Customers
GO
-- Make a change to a customer
UPDATE src.Customers
SET PostalCode = '547855', City = 'S', Region='Washington', Country = 'United States'
WHERE CustomerID = 2
GO

-- Now see the net changes
DECLARE @from_Date datetime, @to_Date datetime
SELECT @from_Date = MAX(LastExtractTime), @to_Date = getdate()
FROM stg.ExtractLog
WHERE SourceName = 'Customers'

DECLARE @from_lsn binary(10), @to_lsn binary(10);
SET @from_lsn = sys.fn_cdc_map_time_to_lsn('smallest greater than', @from_Date);
SET @to_lsn = sys.fn_cdc_map_time_to_lsn('largest less than or equal', @to_Date);

IF (@from_lsn IS NULL )OR (@to_lsn IS NULL)
	PRINT 'There has been no logged database activity in the specified time interval'
ELSE
SELECT *
FROM cdc.fn_cdc_get_net_changes_src_Customers(@from_lsn, @to_lsn, 'all')
ORDER BY CustomerID
GO

-- Check for changes in an interval with no database activity
DECLARE @from_lsn binary(10), @to_lsn binary(10);
SET @from_lsn = sys.fn_cdc_map_time_to_lsn('smallest greater than', DateAdd(ss, -5, GetDate()));
SET @to_lsn = sys.fn_cdc_map_time_to_lsn('largest less than or equal', GetDate());
IF (@from_lsn IS NULL )OR (@to_lsn IS NULL)
	PRINT 'There has been no logged database activity in the specified time interval'
ELSE
SELECT *
FROM cdc.fn_cdc_get_net_changes_src_Customers(@from_lsn, @to_lsn, 'all')
ORDER BY CustomerID
GO