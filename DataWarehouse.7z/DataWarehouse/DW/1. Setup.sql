-- CREATE A DATABASE
USE master
GO

IF EXISTS (SELECT *FROM sys.sysdatabases WHERE name = 'DATAW')
BEGIN
	USE DATAW
	EXEC sys.sp_cdc_disable_table
	@source_schema = N'src',
	@source_name   = N'Customers',
	@capture_instance = 'all'

	EXEC sys.sp_cdc_disable_table
	@source_schema = N'src',
	@source_name   = N'Shippers',
	@capture_instance = 'all'

	EXEC sys.sp_cdc_disable_db
	
	USE master
	DROP DATABASE DATAW
END
GO

-- remove CDC jobs from SQL Agent
DECLARE @numJobs int
SET @numJobs = (SELECT count(*) FROM msdb.dbo.sysjobs_view WHERE name LIKE 'cdc.DemoDW%')
WHILE @numJobs > 0
BEGIN
 DECLARE @jobName nvarchar(128)
 SELECT @jobName = (SELECT MIN(name) FROM msdb.dbo.sysjobs_view WHERE name LIKE 'cdc.DemoDW%')
 EXEC msdb.dbo.sp_delete_job @job_name = @jobName
 SET @numJobs = (SELECT count(*) FROM msdb.dbo.sysjobs_view WHERE name LIKE 'cdc.DemoDW%')
END
GO

CREATE DATABASE DATAW
GO

USE DATAW
GO


-- Create schemas
CREATE SCHEMA dw
GO

CREATE SCHEMA src
GO

CREATE SCHEMA stg
GO

-- CREATE DIMENSION TABLES
CREATE TABLE dw.DimProduct
(ProductKey int identity NOT NULL PRIMARY KEY NONCLUSTERED,
 ProductAltKey nvarchar(10) NOT NULL,
 ProductName nvarchar(50) NULL,
 ProductDescription nvarchar(100) NULL,
 ProductCategoryName nvarchar(50))
GO

CREATE TABLE dw.DimGeography
 (GeographyKey int identity NOT NULL PRIMARY KEY NONCLUSTERED,
  PostalCode nvarchar(15) NULL,
  City nvarchar(50) NULL,
  Region nvarchar(50) NULL,
  Country nvarchar(50) NULL)
GO

 CREATE TABLE dw.DimCustomer
(CustomerKey int identity NOT NULL PRIMARY KEY NONCLUSTERED,
 CustomerAltKey nvarchar(10) NOT NULL,
 CustomerName nvarchar(50) NULL,
 CustomerEmail nvarchar(50) NULL,
 CustomerGeographyKey int NULL REFERENCES dw.DimGeography(GeographyKey),
 CurrentRecord bit)
GO


CREATE TABLE dw.DimSalesperson
(SalespersonKey int identity NOT NULL PRIMARY KEY NONCLUSTERED,
 SalesPersonAltKey nvarchar(10) NOT NULL,
 SalespersonName nvarchar(50) NULL,
 StoreName nvarchar(50) NULL,
 StoreGeographyKey int NULL REFERENCES dw.DimGeography(GeographyKey),
 CurrentRecord bit)
 GO

 CREATE TABLE dw.DimShipper
(ShipperKey int identity NOT NULL PRIMARY KEY NONCLUSTERED,
 ShipperAltKey nvarchar(10) NOT NULL,
 ShipperName nvarchar(50) NULL,
 Deleted bit DEFAULT 0)
GO

CREATE TABLE dw.DimDate
 (DateKey int NOT NULL PRIMARY KEY NONCLUSTERED,
  DateAltKey datetime NOT NULL,
  CalendarYear int NOT NULL,
  CalendarQuarter int NOT NULL,
  MonthOfYear int NOT NULL,
  [MonthName] nvarchar(15) NOT NULL,
  [DayOfMonth] int NOT NULL,
  [DayOfWeek] int NOT NULL,
  [DayName] nvarchar(15) NOT NULL,
  FiscalYear int NOT NULL,
  FiscalQuarter int NOT NULL)
GO

  -- CREATE A FACT TABLE
 CREATE TABLE dw.FactSalesOrders
  (ProductKey int NOT NULL REFERENCES dw.DimProduct(ProductKey),
   CustomerKey int NOT NULL REFERENCES dw.DimCustomer(CustomerKey),
   SalespersonKey int NOT NULL REFERENCES dw.DimSalesperson(SalespersonKey),
   ShipperKey int NULL REFERENCES dw.DimShipper(ShipperKey),
   OrderDateKey int NOT NULL REFERENCES dw.DimDate(DateKey),
   OrderNo int NOT NULL,
   ItemNo int NOT NULL,
   Quantity int NOT NULL,
   SalesAmount money NOT NULL,
   Cost money NOT NULL
    CONSTRAINT [PK_ FactSalesOrder] PRIMARY KEY NONCLUSTERED
 (
	[ProductKey],[CustomerKey],[SalesPersonKey],[OrderDateKey],[OrderNo],[ItemNo]
 )
 )
GO

-- POPULATE THE TABLES
DECLARE @StartDate datetime
DECLARE @EndDate datetime
SET @StartDate = dateadd(YEAR, -1, getdate())
SET @EndDate = dateadd(YEAR, 1, getdate())
DECLARE @LoopDate datetime
SET @LoopDate = @StartDate
WHILE @LoopDate <= @EndDate
BEGIN
  INSERT INTO dw.DimDate VALUES
	(
		CAST(CONVERT(VARCHAR(8), @LoopDate, 112) AS int) , -- date key
		@LoopDate, -- date alt key
		Year(@LoopDate), -- calendar year
		datepart(qq, @LoopDate), -- calendar quarter
		Month(@LoopDate), -- month number of year
		datename(mm, @LoopDate), -- month name
		Day(@LoopDate),  -- day number of month
		datepart(dw, @LoopDate), -- day number of week
		datename(dw, @LoopDate), -- day name of week
		CASE
			WHEN Month(@LoopDate) < 7 THEN Year(@LoopDate)
			ELSE Year(@Loopdate) + 1
		 END, -- Fiscal year (assuming fiscal year runs from Jul to June)
		 CASE
			WHEN Month(@LoopDate) IN (1, 2, 3) THEN 3
			WHEN Month(@LoopDate) IN (4, 5, 6) THEN 4
			WHEN Month(@LoopDate) IN (7, 8, 9) THEN 1
			WHEN Month(@LoopDate) IN (10, 11, 12) THEN 2
		 END -- fiscal quarter 
	)  		  
	SET @LoopDate = DateAdd(dd, 1, @LoopDate)
END
GO

INSERT INTO dw.DimGeography
VALUES
('10001', 'New York', 'New York', 'United States')
GO

INSERT INTO dw.DimGeography
VALUES
('98101', 'Seattle', 'Washington', 'United States')
GO

INSERT INTO dw.DimGeography
VALUES
('90010', 'Los Angeles', 'California', 'United States')
GO

INSERT INTO dw.DimProduct
VALUES
('1', 'Red Racer 100', 'Red racing bike', 'Bikes')
GO

INSERT INTO dw.DimProduct
VALUES
('2', 'Blue Racer 100', 'Blue racing bike', 'Bikes')
GO

INSERT INTO dw.DimProduct
VALUES
('3', 'Racing Gloves', 'Gloves for racing', 'Clothing')
GO

INSERT INTO dw.DimProduct
VALUES
('4', 'Helmet', 'Cycling helmet', 'Clothing')
GO

INSERT INTO dw.DimCustomer
VALUES
('1', 'Ellen Adams', 'ellen@adatum.com', 1, 1)
GO

INSERT INTO dw.DimCustomer
VALUES
('2', 'Walter Harp', 'walter@northwindtraders.com', 1, 1)
GO

INSERT INTO dw.DimCustomer
VALUES
('3', 'Holly Holt', 'holly@wingtiptoys.com', 1, 1)
GO

INSERT INTO dw.DimCustomer
VALUES
('4', 'Jeff Price', 'jeff@proseware.com', 2, 1)
GO

INSERT INTO dw.DimCustomer
VALUES
('5', 'Roya Asbari', 'roya@adatum.com', 3, 1)
GO

INSERT INTO dw.DimSalesperson
VALUES
('1', 'Wendy Khan', 'New York Bike Store', 1, 1)
GO

INSERT INTO dw.DimSalesperson
VALUES
('2', 'Andy Jacobs', 'Seattle Bike Store', 2, 1)
GO

INSERT INTO dw.DimSalesperson
VALUES
('3', 'Matt Berg', 'LA Bike Store', 3, 1)
GO

INSERT INTO dw.FactSalesOrders
VALUES
(1, 1, 1, NULL, CAST(CONVERT(VARCHAR(8), dateadd(dd, -2, getdate()), 112) AS int), 1001, 1, 1, 200, 100)
GO

INSERT INTO dw.FactSalesOrders
VALUES
(3, 1, 1, NULL,  CAST(CONVERT(VARCHAR(8), dateadd(dd, -2, getdate()), 112) AS int), 1001, 2, 1, 20, 10)
GO

INSERT INTO dw.FactSalesOrders
VALUES
(2, 2, 2, NULL, CAST(CONVERT(VARCHAR(8), dateadd(dd, -1, getdate()), 112) AS int), 1002, 1, 1, 200, 100)
GO

INSERT INTO dw.FactSalesOrders
VALUES
(4, 3, 3, NULL, CAST(CONVERT(VARCHAR(8), dateadd(dd, -1, getdate()), 112) AS int), 1003, 1, 1, 25, 10)
GO

INSERT INTO dw.FactSalesOrders
VALUES
(1, 4, 1, NULL, CAST(CONVERT(VARCHAR(8), dateadd(dd, -1, getdate()), 112) AS int), 1004, 1, 1, 200, 100)
GO


-- Create staging tables
CREATE TABLE stg.Products
(ProductID int,
 ProductName nvarchar(50),
 ProductDescription nvarchar(100),
 ProductCategoryName nvarchar(50))
GO

CREATE TABLE stg.Customers
(CustomerID nvarchar(10) NOT NULL,
 CustomerName nvarchar(50) NULL,
 CustomerEmail nvarchar(50) NULL,
 PostalCode nvarchar(15) NULL,
 City nvarchar(50) NULL,
 Region nvarchar(50) NULL,
 Country nvarchar(50) NULL)
GO

CREATE TABLE stg.Salespeople
(SalesPersonID nvarchar(10) NOT NULL,
 SalespersonName nvarchar(50) NULL,
 StoreName nvarchar(50) NULL,
 PostalCode nvarchar(15) NULL,
 City nvarchar(50) NULL,
 Region nvarchar(50) NULL,
 Country nvarchar(50) NULL)
GO

 CREATE TABLE stg.ShipperInserts
(ShipperID nvarchar(10) NOT NULL,
 ShipperName nvarchar(50) NULL)
GO

 CREATE TABLE stg.ShipperUpdates
(ShipperID nvarchar(10) NOT NULL,
 ShipperName nvarchar(50) NULL)
GO

 CREATE TABLE stg.ShipperDeletes
(ShipperID nvarchar(10) NOT NULL,
 ShipperName nvarchar(50) NULL)
GO

CREATE TABLE stg.SalesOrders
  (OrderNo int NOT NULL,
   ItemNo int NOT NULL,
   ProductID int,
   CustomerID int,
   SalespersonID int,
   ShipperID int,
   OrderDate datetime,
   Quantity int NOT NULL,
   SalesAmount money NOT NULL,
   Cost money NOT NULL)
GO

CREATE TABLE stg.ExtractLog
(SourceName varchar(20),
 LastExtractTime datetime,
 LastExtractedVersion int)
GO

-- Insert extract log data
INSERT INTO stg.ExtractLog
VALUES
('Products', dateadd(DAY, -1, getdate()), 0)
GO

INSERT INTO stg.ExtractLog
VALUES
('Customers', dateadd(DAY, -1, getdate()), 0)
GO

INSERT INTO stg.ExtractLog
VALUES
('Salespeople', dateadd(DAY, -1, getdate()), 0)
GO

INSERT INTO stg.ExtractLog
VALUES
('SalesOrders', dateadd(DAY, -1, getdate()), 0)
GO

-- Create source tables
CREATE TABLE src.Products
(ProductID int PRIMARY KEY,
 ProductName nvarchar(50),
 ProductDescription nvarchar(100),
 ProductCategoryName nvarchar(50),
 LastModified datetime)
GO

CREATE TABLE src.Customers
(CustomerID int PRIMARY KEY,
 CustomerName nvarchar(50) NULL,
 CustomerEmail nvarchar(50) NULL,
 PostalCode nvarchar(15) NULL,
 City nvarchar(50) NULL,
 Region nvarchar(50) NULL,
 Country nvarchar(50) NULL)
GO

CREATE TABLE src.Salespeople
(SalesPersonID int PRIMARY KEY,
 SalespersonName nvarchar(50) NULL,
 StoreName nvarchar(50) NULL,
 PostalCode nvarchar(15) NULL,
 City nvarchar(50) NULL,
 Region nvarchar(50) NULL,
 Country nvarchar(50) NULL)
GO

 CREATE TABLE src.Shippers
(ShipperID nvarchar(10) NOT NULL PRIMARY KEY,
 ShipperName nvarchar(50) NULL)
GO

CREATE TABLE src.SalesOrders
  (OrderNo int NOT NULL,
   ItemNo int NOT NULL,
   ProductID int,
   CustomerID int,
   SalespersonID int,
   ShipperID int,
   OrderDate datetime,
   Quantity int NOT NULL,
   SalesAmount money NOT NULL,
   Cost money NOT NULL)
GO

-- Insert source data
INSERT INTO src.Customers
VALUES
(1, 'Ellen Adams', 'ellen@adatum.com','10001', 'New York', 'New York', 'United States')
GO

INSERT INTO src.Customers
VALUES
(2, 'Walter Harp', 'walter@northwindtraders.com', '10001', 'New York', 'New York', 'United States')
GO

INSERT INTO src.Customers
VALUES
(88, 'Holly Holt', 'holly@wingtiptoys.com', '10001', 'New York', 'New York', 'United States')
GO

INSERT INTO src.Customers
VALUES
(44, 'Jeff Price', 'jeff@proseware.com', '98101', 'Seattle', 'Washington', 'United States')
GO

INSERT INTO src.Customers
VALUES
(11, 'Roya Asbari', 'roya@adatum.com', '90010', 'Los Angeles', 'California', 'United States')
GO

Update src.Customers 
Set City='Manouba'
WHERE CustomerID=5
go

INSERT INTO src.Salespeople
VALUES
(1, 'Wendy Khan', 'New York Bike Store', '10001', 'New York', 'New York', 'United States')
GO

INSERT INTO src.Salespeople
VALUES
(2, 'Andy Jacobs', 'Seattle Bike Store', '98101', 'Seattle', 'Washington', 'United States')
GO

INSERT INTO src.Salespeople
VALUES
(3, 'Matt Berg', 'LA Bike Store', '90010', 'Los Angeles', 'California', 'United States')
GO

INSERT INTO src.Products
VALUES
(1, 'Red Racer 100', 'Red racing bike', 'Bikes', dateadd(MONTH, -1, getdate()))
GO

INSERT INTO src.Products
VALUES
(2, 'Blue Racer 100', 'Blue racing bike', 'Bikes', dateadd(MONTH, -1, getdate()))
GO

INSERT INTO src.Products
VALUES
(3, 'Racing Gloves', 'Gloves for racing', 'Clothing', dateadd(MONTH, -1, getdate()))
GO

INSERT INTO src.Products
VALUES
(4, 'Helmet', 'Cycling helmet', 'Clothing', dateadd(MONTH, -1, getdate()))
GO

INSERT INTO src.Shippers
VALUES
(1, 'Shipper One')
GO

INSERT INTO src.Shippers
VALUES
(2, 'Shipper Two')
GO

INSERT INTO src.Shippers
VALUES
(3, 'Shipper Three')
GO

INSERT INTO src.Shippers
VALUES
(4, 'Shipper Four')
GO

INSERT INTO src.SalesOrders
VALUES
(1001, 1, 1, 1, 1, 1, dateadd(dd, -2, getdate()), 1, 200, 100)
GO

INSERT INTO src.SalesOrders
VALUES
(1001, 2, 3, 1, 1, 2, dateadd(dd, -2, getdate()), 1, 20, 10)
GO

INSERT INTO src.SalesOrders
VALUES
(1002, 1, 2, 2, 2, 3, dateadd(dd, -1, getdate()), 1, 200, 100)
GO

INSERT INTO src.SalesOrders
VALUES
(1003, 1, 4, 3, 3, 4, dateadd(dd, -1, getdate()), 1, 25, 10)
GO

INSERT INTO src.SalesOrders
VALUES
(1004, 1, 1, 4, 1, 1, dateadd(dd, -1, getdate()), 1, 200, 100)
GO
select * from  src.Customers