IF EXISTS ( SELECT  * FROM    dbo.sysobjects WHERE   id = OBJECT_ID(N'Etudiant_Src') AND OBJECTPROPERTY(id, N'IsUserTable') = 1 )
DROP TABLE Etudiant_Src
CREATE TABLE Etudiant_Src(ETId int, Nom varchar(50), Prenom varchar(50), Universite varchar(50))
go
insert into Etudiant_Src values(1, 'Secrafi', 'Mounir', 'Gabes')
insert into Etudiant_Src values(5, 'Zemni', 'Habib', 'Carthage')
insert into Etudiant_Src values(2, 'Tounsi', 'Ahmed', 'Sfax')
insert into Etudiant_Src values(7, 'Ben ALi', 'Samir', 'Jendouba')

go
IF EXISTS ( SELECT  * FROM    dbo.sysobjects WHERE   id = OBJECT_ID(N'DimETudiant') AND OBJECTPROPERTY(id, N'IsUserTable') = 1 )
DROP TABLE DimETudiant

CREATE TABLE DimETudiant(Id int identity, ETId int, Nom varchar(50), Prenom varchar(50),  Universite varchar(50), StartDate datetime, 
EndDate datetime)
go


select * from Etudiant_Src
select * from DimETudiant






--SCD Type 1 (Changing Attribute)
update dbo.Etudiant_Src
set prenom = 'Hb'
where ETid=5
go

--SCD Type 2 (Historical Attribute)
update dbo.Etudiant_Src
set Universite = 'Tunis'
where ETId=1
go

--SCD Fixed Attribute
update dbo.Etudiant_Src
set nom = 'Tounsi'
where ETId=7



