USE DemoDW
GO

TRUNCATE TABLE stg.ShipperInserts
GO

INSERT INTO src.Shippers
VALUES
(5, 'Shipper Five')
GO

UPDATE src.Shippers
SET ShipperName = 'Shipper 1'
WHERE ShipperID = 1
GO

DELETE FROM src.Shippers
WHERE ShipperID = 2
GO