-- Enable Change Tracking
USE master
GO

ALTER DATABASE DATAW
SET CHANGE_TRACKING = ON
	(CHANGE_RETENTION = 7 DAYS, AUTO_CLEANUP = ON)
GO

ALTER DATABASE DATAW
SET ALLOW_SNAPSHOT_ISOLATION ON
GO

USE DATAW
GO

ALTER TABLE src.Salespeople
ENABLE CHANGE_TRACKING
WITH (TRACK_COLUMNS_UPDATED = ON)
GO


-- Obtain the initial data and log the current version number
DECLARE @current_version BigInt
SET @current_version = CHANGE_TRACKING_CURRENT_VERSION();

SELECT * FROM src.Salespeople

UPDATE stg.ExtractLog
SET LastExtractedVersion = @current_version
WHERE SourceName = 'Salespeople'
GO

-- Insert a new salesperson
INSERT INTO src.Salespeople
VALUES
(4, 'Howard Gonzalez', 'New York Bike Store', '10001', 'New York', 'New York', 'United States')
GO

-- Update a salesperson
UPDATE src.Salespeople
SET StoreName = 'Seattle Bike Store',
	PostalCode='98001',
	Region='Washington',
	Country='United States'
WHERE SalesPersonID = 1
GO


-- Retrieve the changes between the last extracted and current versions
SET TRANSACTION ISOLATION LEVEL SNAPSHOT

DECLARE @previous_version BigInt
SELECT @previous_version = MAX(LastExtractedVersion)
FROM stg.ExtractLog
WHERE SourceName = 'Salespeople'

DECLARE @current_version BigInt
SET @current_version = CHANGE_TRACKING_CURRENT_VERSION();

SELECT  @previous_version 'Previously retrieved Version',
	    @current_version 'Current version',
		CT.SalesPersonID,
        r.SalespersonName,
		r.StoreName,
		r.PostalCode,
		r.City,
		r.Region,
		r.Country
FROM
CHANGETABLE(CHANGES src.Salespeople, @previous_version) CT
INNER JOIN src.Salespeople r ON CT.SalesPersonID = r.SalesPersonID

UPDATE stg.ExtractLog
SET LastExtractedVersion = @current_version
WHERE SourceName = 'Salespeople'

SET TRANSACTION ISOLATION LEVEL READ COMMITTED
GO

